
import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';
import { BackendAccessService } from '../backend-access.service';
import { HttpClient } from '@angular/common/http';
 
 
@Component({
  selector: 'app-contactus',
  templateUrl: './contactus.component.html',
  styleUrls: ['./contactus.component.css'],
})
export class ContactusComponent {
 
  expresponse : string ="";
  contactList : any =[];
  // ... other properties ...
 
  constructor(private http:HttpClient,private contactService:  BackendAccessService) {}
 
  addContact(form : NgForm){
    this.http.post('http://localhost:9901/insertUser', form.value ).subscribe((response) => {
      this.expresponse = response.toString();
    })
    return this.expresponse;
  }
  getAllContacts(){
    this.http.get('http://localhost:9901/getAllUser').subscribe((response) => {
      this.contactList = response;
    })
    return this.contactList;
  }
  updateContact(form : NgForm){
    this.http.put('http://localhost:9901/updateUser', form.value ).subscribe((response) => {
      this.expresponse = response.toString();
    })
    return this.expresponse;
  }
  deleteContact(form : NgForm){
    this.http.post('http://localhost:9901/deleteUser', form.value ).subscribe((response) => {
      this.expresponse = response.toString();
    })
    return this.expresponse;
  }
}
 
 
 
 
 
 
 
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
 
 
 
@Injectable({
  providedIn: 'root',
})
export class  BackendAccessService {
  private baseUrl = 'http://localhost:9901';
 
  constructor(private http: HttpClient) {}
 
  // Method to add a contact
  addContact(contactData: any): Observable<any> {
    return this.http.post(`${this.baseUrl}/insertUser`, contactData);
  }
 
  // Method to get all contacts
  getAllContacts(): Observable<any> {
    return this.http.get(`${this.baseUrl}/getAllUser`);
  }
 
  // Method to update a contact
  updateContact(contactData: any): Observable<any> {
    return this.http.put(`${this.baseUrl}/updateUser`, contactData);
  }
 
  // Method to delete a contact
  deleteContact(contactData: any): Observable<any> {
    return this.http.post(`${this.baseUrl}/deleteUser`, contactData);
  }
}